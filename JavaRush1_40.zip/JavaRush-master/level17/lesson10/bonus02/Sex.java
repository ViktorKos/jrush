package com.javarush.test.level17.lesson10.bonus02;

public enum Sex {
    MALE,
    FEMALE
}

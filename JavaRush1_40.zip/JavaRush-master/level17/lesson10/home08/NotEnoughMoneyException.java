package com.javarush.test.level17.lesson10.home08;

public class NotEnoughMoneyException extends Exception {
}

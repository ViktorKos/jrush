package com.javarush.test.level15.lesson12.bonus01;

/**
 * Created by Igor on 11.08.2015.
 */
public class Helicopter implements Flyable
{
    @Override
    public void fly()
    {

    }
}

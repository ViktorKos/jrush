package com.javarush.test.level15.lesson12.bonus01;

/**
 * Created by Igor on 11.08.2015.
 */
public class Plane implements Flyable
{
    public Plane(int passengers)
    {
    }

    @Override
    public void fly()
    {

    }
}

package com.javarush.test.level15.lesson12.home07;

public class Constants {
    public static String FILE_NAME = "c:/1.txt"/* add your path to source file here*/;
}

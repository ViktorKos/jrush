package com.javarush.test.level16.lesson13.bonus01.common;

/**
 * Created by Igor on 25.08.2015.
 */
public class BmpReader implements ImageReader
{
}

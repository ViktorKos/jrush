package com.javarush.test.level11.lesson11.home06;

/* Первая правильная «цепочка наследования»
Расставь правильно «цепочку наследования» в классах: Pet (домашнее животное), Cat (кот), Dog(собака).
*/

public class Solution
{
    public static void main(String[] args)
    {
    }

    public class Pet
    {

    }

    public class Cat extends Pet
    {

    }

    public class Dog extends Pet
    {

    }
}

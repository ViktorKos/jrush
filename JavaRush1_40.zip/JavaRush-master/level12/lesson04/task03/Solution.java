package com.javarush.test.level12.lesson04.task03;

/* Пять методов print с разными параметрами
Написать пять методов print с разными параметрами.
*/

public class Solution
{
    public static void main(String[] args)
    {

    }

    //Напишите тут ваши методы
    public void print(int i){

    }
    public void print(int i, int j){

    }
    public void print(int i, int j, int k){

    }
    public void print(int i, int j, int k, int m){

    }
    public void print(int i, int j, int k, int m, int n){

    }


}

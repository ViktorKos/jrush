package com.javarush.test.level12.lesson04.task02;

/* print(int) и print(Integer)
Написать два метода: print(int) и print(Integer).
Написать такой код в методе main, чтобы вызвались они оба.
*/

public class Solution
{
    public static void main(String[] args)
    {
        print(7);
        print(20);
    }

    //Напишите тут ваши методы
    public static int print(int i) {
        return 0;
    }
    public void print(Integer i) {
    }
}

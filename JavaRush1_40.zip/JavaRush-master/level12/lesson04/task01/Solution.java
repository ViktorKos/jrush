package com.javarush.test.level12.lesson04.task01;

/* print(int) и print(String)
Написать два метода: print(int) и print(String).
*/

public class Solution
{
    public static void main(String[] args)
    {

    }

    //Напишите тут ваши методы
    public void print(int i) {
    }
    public void print(String s) {

    }
}

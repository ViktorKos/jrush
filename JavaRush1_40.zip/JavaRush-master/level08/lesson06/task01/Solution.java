package com.javarush.test.level08.lesson06.task01;

import java.util.*;

/* Создать два списка LinkedList и ArrayList
Нужно создать два списка – LinkedList и ArrayList.
*/

public class Solution
{
    public static Object createArrayList()
    {

        List<Object> arr = new ArrayList<Object>();
        return arr;
    }

    public static Object createLinkedList()
    {
        List<Object> arr = new LinkedList<Object>();
        return arr;
    }


}

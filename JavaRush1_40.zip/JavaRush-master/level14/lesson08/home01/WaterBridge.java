package com.javarush.test.level14.lesson08.home01;

/**
 * Created by Igor on 29.07.2015.
 */
public class WaterBridge implements Bridge {

    @Override
    public int getCarsCount()
    {
        return 5;
    }
}
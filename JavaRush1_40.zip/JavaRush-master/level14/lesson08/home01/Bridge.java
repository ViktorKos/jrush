package com.javarush.test.level14.lesson08.home01;

/**
 * Created by Igor on 29.07.2015.
 */
public interface Bridge {
    public int getCarsCount();
}


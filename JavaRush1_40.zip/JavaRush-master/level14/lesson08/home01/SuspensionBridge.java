package com.javarush.test.level14.lesson08.home01;

/**
 * Created by Igor on 29.07.2015.
 */
public class SuspensionBridge implements Bridge {

    @Override
    public int getCarsCount()
    {
        return 10;
    }
}
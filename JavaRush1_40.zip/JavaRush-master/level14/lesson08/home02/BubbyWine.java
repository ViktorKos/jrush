package com.javarush.test.level14.lesson08.home02;

/**
 * Created by Igor on 29.07.2015.
 */
public class BubbyWine extends Wine
{
    public String getHolidayName() {
        return "Новый год";
    }
}

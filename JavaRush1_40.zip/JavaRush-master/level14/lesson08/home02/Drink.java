package com.javarush.test.level14.lesson08.home02;

/**
 * Created by Igor on 29.07.2015.
 */
public abstract class Drink
{
    public void taste() {
        System.out.println("Вкусно");
    }
}

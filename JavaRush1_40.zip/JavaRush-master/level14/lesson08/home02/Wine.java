package com.javarush.test.level14.lesson08.home02;

/**
 * Created by Igor on 29.07.2015.
 */
public class Wine extends Drink
{
    public String getHolidayName() {
        return "День рождения";
    }
}

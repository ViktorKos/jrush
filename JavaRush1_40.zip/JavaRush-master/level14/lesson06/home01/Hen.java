package com.javarush.test.level14.lesson06.home01;

/**
 * Created by Igor on 29.07.2015.
 */
public abstract class Hen {
    public abstract int getCountOfEggsPerMonth();


    public String getDescription() {
        return "Я курица.";
    }

}
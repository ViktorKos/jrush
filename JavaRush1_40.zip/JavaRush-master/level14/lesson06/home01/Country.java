package com.javarush.test.level14.lesson06.home01;

public interface Country
{
    String UKRAINE = "Ukraine";
    String RUSSIA = "Russia";
    String MOLDOVA = "Moldova";
    String BELARUS = "Belarus";
}

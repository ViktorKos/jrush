package com.javarush.test.level18.lesson08.task04;

public class UnsupportedFileNameException extends Exception {
}

package com.javarush.test.level13.lesson11.home02;

public interface Weather
{
    String getWeatherType();
}

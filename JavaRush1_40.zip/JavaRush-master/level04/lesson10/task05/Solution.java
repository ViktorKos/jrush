package com.javarush.test.level04.lesson10.task05;

/* Таблица умножения
Вывести на экран таблицу умножения 10х10 используя цикл while.
Числа разделить пробелом.
1 2 3 4 5 6 7 8 9 10
2 4 6 8 10 12 14 16 18 20
...
*/

public class Solution
{
    public static void main(String[] args) throws Exception
    {
        //Напишите тут ваш код
        /*int s = 1;
        while (s<=1)
        {
            System.out.println();
            s++;


            int j = 0;
            while (j <= 10)
            {
                System.out.print(j + " ");
                j++;
            }
            System.out.println();
            int i = 1;
            while (i <= 20)
            {
                i = i + 1;
                System.out.print(i + " ");
                i++;
            }
            System.out.println();
            int k = 1;
            while (k <= 30)
            {
                k = k + 2;
                System.out.print(k + " ");
                k++;
            }
            System.out.println();
            int a = 1;
            while (a <= 40)
            {
                a = a + 3;
                System.out.print(a + " ");
                a++;
            }
            System.out.println();
            int b = 1;
            while (b <= 50)
            {
                b = b + 4;
                System.out.print(b + " ");
                b++;
            }
            System.out.println();
            int c = 1;
            while (c <= 60)
            {
                c = c + 5;
                System.out.print(c + " ");
                c++;
            }
            System.out.println();
            int d = 1;
            while (d <= 70)
            {
                d = d + 6;
                System.out.print(d + " ");
                d++;
            }
            System.out.println();
            int e = 1;
            while (e <= 80)
            {
                e = e + 7;
                System.out.print(e + " ");
                e++;
            }
            System.out.println();
            int f = 1;
            while (f <= 90)
            {
                f = f + 8;
                System.out.print(f + " ");
                f++;
            }
            System.out.println();
            int g = 1;
            while (g <= 100)
            {
                g = g + 9;
                System.out.print(g + " ");
                g++;
            }
        }
*/
        int i = 1;
        while (i <= 10)
        {
            int j = 1;
            while (j <= 10)
            {
                System.out.print ((i*j) + " ");
                j++;
            }
            System.out.println();
            i++;
        }
        }


    }


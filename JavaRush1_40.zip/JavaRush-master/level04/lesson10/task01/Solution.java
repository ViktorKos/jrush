package com.javarush.test.level04.lesson10.task01;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/* 10 чисел
Вывести на экран числа от 1 до 10 используя цикл while.
*/

public class Solution
{
    public static void main(String[] args) throws Exception
    {
        //Напишите тут ваш код
        int i = 1;
        while (i <= 10)
        {
            System.out.println(i);
            i++;
        }

    }
}